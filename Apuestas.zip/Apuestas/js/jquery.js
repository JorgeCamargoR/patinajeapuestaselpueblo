$(document).ready(function(){

   $('.logoprincipal').hide();
   $('.nombreapuestas').hide();
   $('.logoprincipal').show(2000);
   $('.nombreapuestas').fadeIn(3000);
  });
