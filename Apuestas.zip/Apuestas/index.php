<!DOCTYPE html>

<html lang="es">

<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width-device-width, initial-scale-1">
	<title>Club Apuestas el Pueblo</title>
	<link rel="stylesheet" href="css/bootstrap.css">

</head>

<body>
	<div class="container-fluid">
	
		<header class="row">


		  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3 " >
		  	<img class="logoprincipal" src="img/logo.png" alt="CLUB DE PATINAJE APUESTAS EL PUEBLO" width="60%">
		  </div>
		  
		  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-9">
		  <h1 class="nombreapuestas">Bienvenido a la familia del Club Apuestas el Pueblo</h1>
		  </div>
		
		 
		 
			
		</header>

		


	</div>

<script src="js/jquery-1.12.3.min.js"></script>
<script src="js/jquery.js"></script>

<script src="js/boostrap.js"></script>
</body>
</html>